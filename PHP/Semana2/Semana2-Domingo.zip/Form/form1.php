<html>
<meta charset="utf-8">

<head>
    <title>Bienvenidos </title>
    <style type="text-css">

        .button{
        border:1px solid #dedede;
        border-radius: 3px;
        color: #555;
        display: inline-block;
        font: bold 12px Arial;
        padding: 8px 11px;
        text-decoration: none;
    }
    </style>
</head>

<body>
    <div align="center">
        <img src="imagen.jpg">
        <font size=10>
            <b><br>Educación Continua</b>
            <b><br>Bienvenidos</b>
        </font>
        <form name="form2" action="form2.php">
        <Input type="submit" name="b1" value="Ingresar al portal" class="button">
        
        </form>
</body>

</html>