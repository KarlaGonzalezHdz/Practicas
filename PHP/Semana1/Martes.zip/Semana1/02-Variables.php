<?php
    $matricula = 606267;
    echo "La matricula es $matricula <br>";
    print ("La matricula es $matricula <br>");
    printf ('Mi matricula es ' .$matricula);
?>