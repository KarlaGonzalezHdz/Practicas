<?php
$i=4;
$n=1;

do
{
    $n=$n*$i;
    $i -=1;
}
while($i>1);
echo "4! es a: ".$n;
?>