<?php
    function saludame()
    {
        echo "Hola programador, ¿Comó estas?.";
        echo "<br>";
        echo "Te espero el domingo";

    }

    saludame();
?>