<html>
<head>
    <title>Ejemplo generando un bucle</title>
</head>
<body>

    <?php
        echo '!Que onda!, como van? Saludos! <br>';
        for ($i =0; $i < 5; $i++)
        {
            echo 'Hola: '.$i.'<br>';
        }
    ?>
    
</body>
</html>