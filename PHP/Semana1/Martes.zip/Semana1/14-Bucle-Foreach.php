<html>
<head>
    <title>Ejemplo de bucle en PHP 7</title>
</head>
<body>
    <?php
        $a = array(1,3,5,11,13);
        foreach ($a as $v)
        {
            echo "Valor actual de \$a: $v <br>";
        }
    ?>
</body>
</html>