<?php
    $str="Hola Mundo";
    print $str;

    $str2="<br> Es la segunda impresion <br>";
    echo $str2;

    $edad= array("Karla" => "22");
    printf("Karla tiene " .$edad["Karla"]." años");
?>