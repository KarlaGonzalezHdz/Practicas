<?php
    $a=11;
    switch ($a)
    {
        case 0:
            echo "a es igual a 13";
        break;
        
        case 1:
            echo "a es igual a 14";
        break;

        case 2: 
            echo "a es igual a 15";
        break;

        default:
            echo "$a no vale 13 , 24 o 15";
        
    }
?>