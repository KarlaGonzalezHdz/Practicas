<?php
    $a = 7;
    $b = 4;
    echo $a+$b."<br>";
    echo $a-$b."<br>";
    echo "La multiplicación a * b es ".$a*$b."<br>";
    echo "La division a / b es ".$a/$b."<br>";
    echo "El módulo a % b es ".$a%$b."<br>";
    $a++;
    echo "Numero mayor a 7 es".$a."<br>";
    $b--;
    echo "Numero menor a 4 es ".$b."<br>";
?>