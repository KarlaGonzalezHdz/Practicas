<?php
    $a =10;
    if($a == 13)
    { echo "$a vale 13";}
    else if($a == 14)
    { echo "$a vale 14";}
    else if ($a == 15)
    { echo "$a vale 15";}
    else 
    { echo "$a no vale ni 13, ni 14 , ni 15";}
?>