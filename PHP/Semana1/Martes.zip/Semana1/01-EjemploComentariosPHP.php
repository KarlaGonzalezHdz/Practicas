<html>
<head>
    <title>Comentarios</title>
    <h3>Ejemplo de comentarios en PHP 7</h3>
</head>
<body>

    <?php
        //Este es el primer tipo de comentario. Podemos agregar tanto texto como queramos sin cambiar de renglón.
        echo "Dejaremos este comentario con // ejemplo de ejecucion de PHP 7";
        echo "<br>";
        # ¡Este es el segundo tipo de comentario!. Podemos agregar tanto texto como queramos sin cambiar de renglón.
        echo "Dejaremos comentario con # como ejemplo de ejecución de PHP 7";
        echo "<br>";
        /*
        ¡Este es un tipo de comentario!. 
        Podemos agregar tanto texto como queramos cambiando de renglón
        sin importar que escribamos
        bajando de renglones
        Hasta su cierre
        */
        echo "Dejaremos este echo como ejemplo de ejecución de PHP 7";
    ?>
    
</body>
</html>