<?php
    $nombre = "Juan Perez";
    $ciudad = "Monterrey";
    $pais = "Mexico";
    $edad = "30";

    echo "Hola, mi nombre es ".$nombre.", vido en la ciudad de ".$ciudad.", en el país ".$pais." y tengo ".$edad." años";

?>