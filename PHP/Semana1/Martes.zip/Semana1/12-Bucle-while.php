<?php
    $i = 1;
    while($i < 5)
    {
        echo $i."<br>";
        $i +=1;
    }
    echo "la variable $i vale: "
    .$i."<br>";
?>