<?php
    //Ejemplo de matricula podemos agregar más lineas
    $matricula = 806267;
    printf("Mi matricula es $matricula");

    //por ejemplo

    echo ' <br> Hola, como estas?';
?>