<?php

    $variable1=1;
    $variable2 = 2;
    $etc=3;
    $etc1=4;
    
    printf("cadena formato, $variable1 , $variable2 , $etc , $etc1");
    printf("<br> el número %d %f %.2f" ,2 , 2, 2);
    echo "<br>el número %d %f %2.f", 2,2,2;
?>