<?php
    $a = 7;
    $b = 4;

    if($a==7 && $b==4)
    { echo "$a es igual a 7 y $b es igual a 4 <br>";}
    else 
    { echo "Alguna condición no cumplió la validación <br>";}

    if($a==7 and $b==4)
    { echo "$a es igual a 7 y $b es igual a 4 <br>";}
    else 
    { echo "Alguna condición no cumplió la validación <br>";}

    if($a==7 || $b==4)
    { echo "$a puede ser igual a 7 y $b puede ser igual a 4 <br>";}
    else
    { echo "Alguna condición no cumplió la validación <br>";}

    if($a==7 or $b==4)
    { echo "$a puede ser igual a 7 y $b puede ser igual a 4 <br>";}
    else
    { echo "Alguna condición no cumplió la validación <br>";}

    if($a!=4)
    { echo "$a no es igual a 4 <br>";}
    else 
    { echo "Alguna condición no cumplió la validación <br>";}

?>