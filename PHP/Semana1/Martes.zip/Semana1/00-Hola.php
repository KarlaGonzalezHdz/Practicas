<?php
#Esto es impresion de php en comentario

//Este es otro comentario

/*
Esto se usa para comentarios de dos o más lineas.
*/ 

    echo "Hola";
    echo "<br>";
    echo "Hola 2";
?>

