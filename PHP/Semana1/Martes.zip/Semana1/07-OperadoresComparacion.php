<?php
//Comparación
    $a = 7;
    $b = 4;

        if($a == $b)
        { echo "$a es igual a $b <br>";}
        else
        { echo "$a no es igual a $b <br>";}

        if($a != $b)
        { echo "$a no es igual a $b <br>";}
        else 
        { echo "$a es igual a $b <br>";}

        if($a < $b )
        { echo "$a  es menor a $b <br>";}
        else 
        { echo "$a no es menor a $b <br>";}

        if($a > $b )
        { echo "$a  es mayor a $b <br>";}
        else 
        { echo "$a no es mayor a $b <br>";}
?>