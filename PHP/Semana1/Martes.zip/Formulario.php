<html>
<body>
    <form action="Formulario1.php" method="get">
    Nombre:
    <input type="text" name="nombre">
    <br>
    Edad:
    <input type="text" name="edad">
    <br>

    <input type="submit" value="guardar">
    </form>
</body>
</html>